package com.abc;

public class MainClass {
	public static void main(String[] args) {
		System.out.println(" Hello All Question answer");
	}

}
