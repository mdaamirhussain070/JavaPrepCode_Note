package com.abc;

import com.abc.StaticNonStaticExample.NonStatic;

public class StaticNonStaticDriverClass {
public static void main(String[] args) {
		
		StaticNonStaticExample obj=new StaticNonStaticExample();
		
//		NonStatic obj1=new NonStatic();
		
//		obj1.show1();
		StaticNonStaticExample.StaticExample ob2=new StaticNonStaticExample.StaticExample();
		
		ob2.show();
		
		
		
		
	}

}
